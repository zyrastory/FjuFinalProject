students = [('john', 'A', 15), ('jane', 'B', 12), ('dave', 'B', 10),]  
abc = sorted(students, key=lambda student : student[2],reverse = False)

print(abc)