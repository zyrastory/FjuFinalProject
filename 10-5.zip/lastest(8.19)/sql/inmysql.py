import pymysql
import csv

mydb= pymysql.connect(host='localhost', port=3306, user='root', passwd='12345', db ='stock',charset='UTF8')
cur = mydb.cursor()

csv_data = csv.reader(open('C:/Users/user/Desktop/sql/test.csv'))
row = []
sql = "DELETE FROM item"
cur.execute(sql)

for row in csv_data:
	cur.execute("INSERT INTO item (dtime,Open,High,Low,Close,Volume) VALUES ('%s','%s','%s','%s','%s','%s')"%(row[0],row[1],row[2],row[3],row[4],row[5]))
	#print("('%s','%s','%s','%s','%s','%s')"%(row[0],row[1],row[2],row[3],row[4],row[5]))
	#cur.execute("INSERT INTO item(dtime,Open,High,Low,Close,Volume) VALUES ('%s','%s','%s','%s','%s','%s')"%row)
	mydb.commit()

#cur.execute('SELECT*FROM test')

#sql ="DELETE FROM account WHERE company = '%s' AND account = '%s' LIMIT 1"%(com,acc)
#sql2 ="INSERT INTO item(Date Time,Open,High,Low,Close,Volume) VALUES ('%s','%s','%s')"%(com,acc,pas)
#sql ="INSERT INTO test(item_name) VALUES ('1500');"
#sql ="DELETE FROM test WHERE ni = 2500 LIMIT 1"

#cur.execute(sql)
#cur.execute(sql2)

#rows=cur.fetchall()


cur.close()