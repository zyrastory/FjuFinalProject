import requests
#from bs4 import BeautifulSoup 
import sys
import json
import time

#url1.0 = "http://www.twse.com.tw/zh/page/trading/exchange/BWIBBU.html"
#url = "http://www.twse.com.tw/exchangeReport/BWIBBU?response=json&"
url = "http://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&"

def test():

    x = ""
    for year in range(2016,2018):
        for month in range(1,13):
            if month<10:
                month = "0"+str(month)
            setting="date="+str(year)+str(month)+"01&stockNo=1101"

            headers = {
                'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36    '
            }
            url_new = url + setting

            res = requests.get(url_new,headers=headers)

            zyra=(res.text.encode(sys.stdin.encoding, "replace").decode(sys.stdin.encoding))
        
            js=json.loads(zyra)

            abc = []
            try:
                for js['data'] in js['data']:
                    #print(js['data'])
                    abc.append(js['data'])
            except:
                break
            #print(zyra['data'])

            
            for a in abc:
                list_need=[0,3,4,5,6,1]

                for i in list_need:
                    if a[1] == "0":
                        break 
                    
                    else:   
                        if i == 1:
                            x+=(a[i].replace(",","")+"\n")
                        elif i ==0:
                            x+=((str(int(a[i][:3])+1911)+a[i][3:])+",")
                        else:
                            x+=(a[i].replace(",","")+",")

            time.sleep(1.5)
                


    with open("test.csv" , 'w', encoding='UTF-8') as w:
        w.write(x)

test()