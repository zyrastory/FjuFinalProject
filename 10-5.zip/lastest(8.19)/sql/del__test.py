import pymysql
import csv

mydb= pymysql.connect(host='localhost', port=3306, user='root', passwd='12345', db ='stock',charset='UTF8')
cur = mydb.cursor()

sql_check = 'SELECT*FROM item'

cur.execute(sql_check)

rows=cur.fetchall()
for rows in rows:
	x = rows[0]
#cur.close()

print(x)
start = str(x)[:8]+"01"+str(x)[10:]
end   = str(x)[:8]+"31"+str(x)[10:]
print(start)
print(end)

sql_check = "DELETE FROM item WHERE dtime BETWEEN '{0}'AND'{1}'".format(start,end)

cur.execute(sql_check)

cur.close()
mydb.commit()


"""
#sql = "DELETE FROM item WHERE dtime BETWEEN '2017-02-01 00:00:00'AND'2017-02-31 00:00:00'"
"""


