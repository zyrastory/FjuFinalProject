import pymysql

def Tocsv(num,a,b):
    mydb= pymysql.connect(host='localhost', port=3306, user='root', passwd='12345', db ='stock',charset='UTF8')
    cur = mydb.cursor()
    dic = {"台泥":'aaa', "中石化":'bbb', "富邦":'ccc', "統一":'ddd', "亞聚":'eee', "中鋼":'fff'
    , "TWSEAUTO":'ggg',"TWSECEM":'hhh',"TWSECON":'iii',"TWSEFOOD":'jjj',"TWSERUB":'kkk',"TWSESTEE":'lll'
    ,"EXF1":'mmm',"FXF1":'nnn',"MXF1":'ooo',"TXF1":'ppp'} 
            
    c = dic[num]

    cur.execute('SELECT*FROM  {0} WHERE {1} BETWEEN "{2}" AND "{3}"'.format(c,"date",a,b)) 
    rows=cur.fetchall()

    x = "Date Time,Open,High,Low,Close,Volume"+"\n"
    for rows in rows:
        for i in range(6):
            if i == 5:
                x+=(str(rows[i])+"\n")
            else:
                x+=(str(rows[i])+",")

    csvname = "0_{0}_{1}_{2}.csv".format(c,a,b)
    with open("./cache/"+csvname , 'w', encoding='UTF-8') as w:
        w.write(x)