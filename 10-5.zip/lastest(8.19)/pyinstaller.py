from PyInstaller.__main__ import run

if __name__ == '__main__':

    opts = ['-F', '-w', '--paths=C:\\Users\\user\\AppData\\Local\\conda\\conda\\envs\\35\\Lib\\site-packages\\PyQt5\\Qt\\bin',
            '--paths=C:\\Users\\user\\AppData\\Local\\conda\\conda\\envs\\35\\Lib\\site-packages\\PyQt5\\Qt\\plugins',
            'xxx.py']

                
    run(opts)