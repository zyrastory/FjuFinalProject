import talib
import numpy as np
import pandas as pd
import datetime as dt
import matplotlib
import sys, os, random
import matplotlib.dates as mdates
import matplotlib.pyplot as plt

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib import style
from matplotlib.finance import candlestick_ohlc
from sql2csv import Tocsv
from matplotlib.figure import Figure
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from matplotlib.backends.backend_qt5 import NavigationToolbar2QT as NavigationToolbar

matplotlib.use('Qt5Agg')
style.use('ggplot')


class Figure_Canvas(QMainWindow):   
#通过继承FigureCanvas类，使得该类既是一个PyQt5的Qwidget，又是一个matplotlib的FigureCanvas，这是连接pyqt5与matplotlib的关键

    def __init__(self, parent=None):
        #fig = Figure(figsize=(width, height), dpi=100)  # 创建一个Figure，注意：该Figure为matplotlib下的figure，不是matplotlib.pyplot下面的figure
        QMainWindow.__init__(self, parent)
        self.setWindowTitle('Demo: PyQt with matplotlib')
        
    
    def test(self,num,a,b,tc):

        Tocsv(num,a,b) #連接到sql2csv
        dic = {"台泥":'aaa', "中石化":'bbb', "富邦":'ccc', "統一":'ddd', "亞聚":'eee', "中鋼":'fff'
    , "TWSEAUTO":'ggg',"TWSECEM":'hhh',"TWSECON":'iii',"TWSEFOOD":'jjj',"TWSERUB":'kkk',"TWSESTEE":'lll'
    ,"EXF1":'mmm',"FXF1":'nnn',"MXF1":'ooo',"TXF1":'ppp'}

        for p in dic:
            if num==p:
                c = dic[p]
        
        
        csvname = "0_"+c+"_"+a+"_"+b
        self.main_frame = QWidget()
        self.dpi = 100
        self.fig = Figure((5.0, 4.0), dpi=self.dpi)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setParent(self.main_frame)

        self.ax1 = self.fig.add_subplot(311)
        self.ax2 = self.fig.add_subplot(312,sharex=self.ax1)

        
        df = pd.read_csv('./cache/'+csvname+".csv", parse_dates=True, index_col=0)
        #parse_dates  True嘗試解析日期索引，index_col 以第幾列當作索引


        df_ohlc = df['Close'].resample(str(tc)+"D").ohlc()
        df_volume = df['Volume'].resample(str(tc)+"D").sum()

        df_ohlc.reset_index(inplace=True)
        df_ohlc['Date Time'] = df_ohlc['Date Time'].map(mdates.date2num)

        #self.ax1 = plt.subplot2grid((6,1), (0,0), rowspan=5, colspan=1)
        #self.ax2 = plt.subplot2grid((6,1), (5,0), rowspan=1, colspan=1, sharex=self.ax1)
        self.ax1.xaxis_date()

        candlestick_ohlc(self.ax1, df_ohlc.values, width=5, colorup='g')
        self.ax2.fill_between(df_volume.index.map(mdates.date2num), df_volume.values, 0)
        
        
        self.mpl_toolbar = NavigationToolbar(self.canvas, self.main_frame)

        hbox = QHBoxLayout()
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.mpl_toolbar)
        vbox.addWidget(self.canvas)
        vbox.addLayout(hbox)
        
        self.main_frame.setLayout(vbox)
        self.setCentralWidget(self.main_frame)


        