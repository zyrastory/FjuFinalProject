from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

import sys

class Window(QTabWidget):
    def __init__(self, parent = None):
        super(Window, self).__init__(parent)
        #self.setStyleSheet("QTabBar::tab { height: 35px; width: 180px;font-size: 18pt}")

        self.listS = QListWidget(self)
        self.listS.addItems(["中石化","台泥"])
        #self.listS.move(200,220)
        self.listS.setFixedSize(250,50)
        self.MSL = QListWidget(self)
        self.MSL.addItems(["石化","台泥"])
        self.MSL.setFixedSize(250,50)
        tab2 = QWidget()
        t2layout = QGridLayout(tab2)
        t2layout.addWidget(self.MSL)
        t2layout.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)

        tab = QWidget()
        tlayout = QGridLayout(tab)
        tlayout.addWidget(self.listS)
        tlayout.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        
        """
        tlayout.addWidget(self.createFistExclusiveGroup())
        tlayout.addWidget(self.createSecondExclusiveGroup())

        t2layout.addWidget(self.createFistExclusiveGroup())
        t2layout.addWidget(self.createSecondExclusiveGroup())
        """

        
        self.setWindowTitle('下單接口')
        self.setFixedSize(480, 420)
        
        self.addTab(tab,"股票")
        self.addTab(tab2,"期貨")


        self.groupBox = QGroupBox('manual to order',self)


        self.groupBox.setCheckable(True)
        self.groupBox.setChecked(True)

        self.buyButton = QPushButton('買進',self)
        self.sellButton = QPushButton('賣出',self)
        self.buyButton.setCheckable(True)
        self.sellButton.setCheckable(True)

        lbN = QLabel('  口數',self)
        lbP = QLabel('  價錢',self)
        nSpin = QSpinBox()
        nSpin.setRange(100,1000000)
        pSpin = QSpinBox()
        pSpin.setRange(100,1000000)
        moButton = QPushButton('手動下單',self)
        emptylb = QLabel(' ')

        grid = QGridLayout()
        grid.addWidget(self.buyButton,0,0)
        grid.addWidget(lbN,0,1)
        grid.addWidget(nSpin,0,2)
        grid.addWidget(emptylb,0,3)
        grid.addWidget(self.sellButton,1,0)
        grid.addWidget(lbP,1,1)
        grid.addWidget(pSpin,1,2)
        grid.addWidget(moButton,1,3)
        self.groupBox.setLayout(grid)


        
        self.groupBox2 = QGroupBox('Auto to order',self)

        self.groupBox2.setCheckable(True)
        self.groupBox2.setChecked(False)

        lbI = QLabel('內建',self)
        lbS = QLabel('自訂',self)
        self.ilistW = QListWidget()
        self.ilistW.addItems(["ma","macd"])
        self.slistW = QListWidget()
        self.slistW.addItems(["dde","ffe"])
        self.ilistW.setFixedSize(185,50)
        self.slistW.setFixedSize(185,50)
        emptylb2 = QLabel(" ")
        auoButton = QPushButton("依策略下單",self)

        ggrid = QGridLayout()
        ggrid.addWidget(lbI,0,0)
        ggrid.addWidget(self.ilistW,0,1)
        ggrid.addWidget(emptylb2,0,2)
        ggrid.addWidget(lbS,1,0)
        ggrid.addWidget(self.slistW,1,1)
        ggrid.addWidget(auoButton,1,2)
        self.groupBox2.setLayout(ggrid)
        

        self.groupBox.move(20,100)
        self.groupBox2.move(20,230)
        self.toggle_1()
        self.bigtimer()
        self.haha()




    def haha(self):
        if  self.groupBox2.isChecked() ==True:
            self.groupBox.setChecked(False)
            QTimer.singleShot(10, self.ahah)
        else:
            QTimer.singleShot(10, self.haha)
    
    def ahah(self):
        if self.groupBox.isChecked()==True:
            self.groupBox2.setChecked(False)
            self.clear(self.slistW)
            self.clear(self.ilistW)
            QTimer.singleShot(10, self.haha)
        else:
            QTimer.singleShot(10, self.ahah)

    def toggle_1(self):
        if self.buyButton.isChecked() == True:
            QTimer.singleShot(10, self.toggle_3)
        else:
            QTimer.singleShot(10, self.toggle_2)
    def toggle_2(self):
        if self.sellButton.isChecked() == True:
            QTimer.singleShot(10, self.toggle_4)
        else:
            QTimer.singleShot(10, self.toggle_1)
    def toggle_3(self):
        if self.buyButton.isChecked() == True:
            self.sellButton.setChecked(False)
            QTimer.singleShot(10, self.toggle_4)
            
        else:
            QTimer.singleShot(10, self.toggle_3)
    def toggle_4(self):
        if self.sellButton.isChecked() == True:
            self.buyButton.setChecked(False)
            QTimer.singleShot(10, self.toggle_3)
            
        else:
            QTimer.singleShot(10, self.toggle_4)


    def bigtimer(self):
        try:
            self.ilistW.selectedItems()[0].text()
            QTimer.singleShot(10, self.timer)
        except:
            QTimer.singleShot(10, self.smalltimer)

    def smalltimer(self):

        try:
            self.slistW.selectedItems()[0].text()
            QTimer.singleShot(10, self.realtimer)
        except:
            QTimer.singleShot(10, self.bigtimer)


    def timer(self):
        try:
            self.ilistW.selectedItems()[0].text()
            self.clear(self.slistW)
            self.realtimer()          
        except:
            QTimer.singleShot(10, self.timer)
    def realtimer(self):

        try:
            self.slistW.selectedItems()[0].text()
            self.clear(self.ilistW)
            self.timer()            
        except:
            QTimer.singleShot(10, self.realtimer)

    def clear(self,listwidget):
        listwidget.clearSelection()

   
"""
app = QApplication(sys.argv)
win = Window()
win.show()
app.exec_()
"""


