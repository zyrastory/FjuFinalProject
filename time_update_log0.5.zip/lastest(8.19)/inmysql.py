import pymysql
import csv
def tocsv(num):
	dic = {1101:'aaa', 1314:'bbb'}
	t = dic[num]
	mydb= pymysql.connect(host='localhost', port=3306, user='root', passwd='12345', db ='stock',charset='UTF8')
	cur = mydb.cursor()
	sql_check = "SELECT*FROM %s"%t
	cur.execute(sql_check)

	#csv_data = csv.reader(open('C:/Users/user/Desktop/lastest(8.19)/test.csv'))

	row = cur.fetchall()
	for row in row:
		x = row[0]
	start = str(x)[:8]+"01"+str(x)[10:]
	end = str(x)[:8]+"31"+str(x)[10:]
	sql_check = "DELETE FROM {0} WHERE date BETWEEN '{1}'AND'{2}'".format(t,start,end)
	cur.execute(sql_check)

	csv_data = csv.reader(open('C:/Users/user/Desktop/lastest(8.19)/test.csv'))

	for row in csv_data:
		cur.execute("INSERT INTO %s (date,Open,High,Low,Close,Volume) VALUES ('%s','%s','%s','%s','%s','%s')"%(t,row[0],row[1],row[2],row[3],row[4],row[5]))
		print("('%s','%s','%s','%s','%s','%s')"%(row[0],row[1],row[2],row[3],row[4],row[5]))
		#cur.execute("INSERT INTO item(dtime,Open,High,Low,Close,Volume) VALUES ('%s','%s','%s','%s','%s','%s')"%row)
		mydb.commit()




	cur.close()
