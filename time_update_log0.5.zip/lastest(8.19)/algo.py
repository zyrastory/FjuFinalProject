from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
import sys
from sql3csv import Tocsv
from datewrong import dateWrong
import os

from pyalgotrade import plotter  
from pyalgotrade.stratanalyzer import returns, sharpe, drawdown, trades  
from pyalgotrade import strategy  
from pyalgotrade.bar import Frequency  
from pyalgotrade.barfeed.csvfeed import GenericBarFeed  
from pyalgotrade import broker
import pyalgotrade

import importlib
import time
import threading

from algolist import resultlist

#sys.path.append('C:\\Users\\user\\Desktop\\lastest(8.19)\\Algorithm')
#from test911 import run


class algoWindow(QMainWindow):
    def __init__(self, parent = None):
        super(algoWindow, self).__init__(parent)
        self.setWindowTitle('新增演算法')
        self.setGeometry(600,300,700,400)

        self.listWidget = QListWidget(self)

        item = QtWidgets.QListWidgetItem()

        item.setText('商品'+'\t'*2+'說明\n'+'-'*53)
        self.start = QLabel("起始",self)
        self.end = QLabel("結束",self)
        self.k = QLabel("K線週期",self)
        
        
        item.setFlags(QtCore.Qt.NoItemFlags)        # item should not be selectable
        self.listWidget.addItem(item)
        self.listWidget.addItems(["%-20s%10s"%("中石化","中國石油化工股份有限公司"), \
            "%-20s%10s"%("台泥","台灣水泥1101")])
        self.listWidget.setFixedSize(330,200)
        
        self.year = QComboBox(self)
        self.month = QComboBox(self)
        self.day = QComboBox(self)
        self.year2 = QComboBox(self)
        self.month2 = QComboBox(self)
        self.day2 = QComboBox(self)
        self.scope = QLineEdit(self)
        self.Tcount = QComboBox(self)


        self.year.addItems([str(x) for x in range(1998,2018)])
        self.month.addItems([str(y) for y in range(1,13)])
        self.day.addItems([str(z) for z in range(1,32)])
        self.year2.addItems([str(a) for a in range(1998,2018)])
        self.month2.addItems([str(b) for b in range(1,13)])
        self.day2.addItems([str(c) for c in range(1,32)])

        self.scope.setPlaceholderText("default:1")  #時間週期輸入框，設定字體大小
        f = self.scope.font()
        f.setPointSize(12) 
        self.scope.setFont(f)

        self.Tcount.addItems(["日","周","月"])
        self.Tcount.resize(40,27.5)


        self.start.move(10,210)    #起始時間標籤

        self.year.move(80, 210)
        self.year.resize(100,25)
        self.month.move(180, 210)
        self.month.resize(100,25)
        self.day.move(280, 210)
        self.day.resize(100,25)

        self.end.move(10,260)  #結束時間標籤
        self.year2.move(80,260)
        self.year2.resize(100,25)
        self.month2.move(180,260)
        self.month2.resize(100,25)
        self.day2.move(280,260)
        self.day2.resize(100,25)
        
        self.k.move(10,310)
        self.scope.move(80,310)
        self.scope.resize(100,25)
        self.Tcount.move(180,310)
        self.Tcount.resize(50,25)

        self.subbutton = QPushButton('確認',self)
        self.subbutton.move(450, 350)


        backbutton = QPushButton('返回',self)
        backbutton.move(550, 350)


        self.groupbox1 = QGroupBox('暴力演算法', self)
        self.groupbox1.setCheckable(True)
        self.groupbox1.setChecked(False)
        self.groupbox1.setFixedSize(250,100)
        self.list1 = QListWidget()
        #self.list1.addItems(["ma","macd","rsi"])
        self.list1.setFixedSize(185,50)
        listA = []
        for dirPath, dirNames, fileNames in os.walk \
        ("C:\\Users\\user\\Desktop\\lastest(8.19)\\strategy\\internal"):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".md") ]
            for f in fileNames:
                listA.append(f.replace(".md",""))
        self.list1.addItems(listA)

        self.grid1 = QGridLayout()
        self.grid1.addWidget(self.list1,0,0)
        self.groupbox1.setLayout(self.grid1)

        self.groupbox1.move(400,20)

        self.subbutton.clicked.connect(lambda:self.compare())
        backbutton.clicked.connect(self.close)



    def compare(self):
        a = None
        itemlist = (['中石化', '台泥'])
        
        mylist = self.listWidget
        
        for i in mylist.selectedItems():
            a = i.text()[:3].replace(" ","")

        if a == None:
            self.dwrongmsg = dateWrong("NE") # no enter
            print ("沒選擇啦嫩")
            self.dwrongmsg.show()

        elif int(self.year.currentText()) > int(self.year2.currentText()):
            self.dwrongmsg = dateWrong("T")   #time error
            print ("date wrong1")
            self.dwrongmsg.show()
        elif int(self.year.currentText()) == int(self.year2.currentText()) and int(self.month.currentText()) >= \
            int(self.month2.currentText()):
            self.dwrongmsg = dateWrong("T")
            print ("date wrong2")
            self.dwrongmsg.show()

        else:
            print ("date right")
            self.tt()
            self.compare2()
            self.close()
        

    def tt(self):
        self.num = str(self.listWidget.selectedItems()[0].text()[:3].replace(" ",""))
        print("stockcombo is "+self.num)
        if self.scope.text()=="":    #如果沒有輸入時間週期，跑預設的1
            self.num2=1
        else:
            self.num2 = int(self.scope.text())
        self.a = str(self.year.currentText())+"-"+str(self.month.currentText())+"-"+str(self.day.currentText())
        self.b = str(self.year2.currentText())+"-"+str(self.month2.currentText())+"-"+str(self.day2.currentText())
        if self.Tcount.currentText() == "日":
            self.tc = self.num2* 1

        elif self.Tcount.currentText() == "周":
            self.tc = self.num2* 7
        
        else:
            self.tc = self.num2* 30            
        print("self.num="+self.num)
        print("self.a="+self.a)
        print("self.b="+self.b)
        print("self.tc="+str(self.tc))
        #self.kline(self.num,self.a,self.b,self.tc)
        Tocsv(self.num,self.a,self.b)

    def compare2(self):
        self.c = None
        for i in self.list1.selectedItems():
            self.c = i.text()
        if self.c == None:
            self.dwrongmsg = dateWrong("NS")
            self.dwrongmsg.show()
        else:
            """
            trd = threading.Thread(target = self.run(self.c))
            trd.start()
            """
            self.run(self.c)
            print(self.c)

    def closeEvent(self, event):
        os.system("del /F/S/Q cache1")

    def ma_th(self,i,c):
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache1"
        sys.path.append(path)
        listA = []
        for dirPath, dirNames, fileNames in os.walk \
            ("C:\\Users\\user\\Desktop\\lastest(8.19)\\cache1"):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listA.append(f.replace(".csv",""))
        print(listA)
        feed = GenericBarFeed(Frequency.DAY, None, None)
        feed.addBarsFromCSV("item", path+"\\%s.csv"%(listA[0]))

        f = open("C:\\Users\\user\\Desktop\\lastest(8.19)\\setting\\setting.md")
        o=[]
        line=f.readline()
        while line:            
            o.append(line)
            line = f.readline()
        if o[1][0] == "P":
            broker_commission = broker.backtesting.TradePercentage(float(o[1][1:]))  
        elif o[1][0] == "F":   
            broker_commission = pyalgotrade.broker.backtesting.FixedPerTrade(int(o[1][1:]))                 
        elif o[1][0] == "N":
            broker_commission = pyalgotrade.broker.backtesting.NoCommission()

        brk = broker.backtesting.Broker(int(o[0]), feed, broker_commission)

        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\strategy\\internal"

        sys.path.append(path)
        a = str(c)
        os.system("rename %s\\%s.md %s.py"%(path,a,a))
        module = importlib.import_module(a, package=None)   #所有內建策略
        MyStrategy = getattr(importlib.import_module(a), 'MyStrategy')

        myStrategy = MyStrategy(feed, "item",brk,i,o[2])

        sharpe_ratio = sharpe.SharpeRatio()
        mytrade = trades.Trades() 
        myStrategy.attachAnalyzer(sharpe_ratio)
        myStrategy.attachAnalyzer(mytrade)

        self.next(i,myStrategy,a,o,self.list_w)

    def macd_th(self,y,x,z,c):
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache1"
        sys.path.append(path)
        listA = []
        for dirPath, dirNames, fileNames in os.walk \
            ("C:\\Users\\user\\Desktop\\lastest(8.19)\\cache1"):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listA.append(f.replace(".csv",""))
        print(listA)
        feed = GenericBarFeed(Frequency.DAY, None, None)
        feed.addBarsFromCSV("item", path+"\\%s.csv"%(listA[0]))

        f = open("C:\\Users\\user\\Desktop\\lastest(8.19)\\setting\\setting.md")
        o=[]
        line=f.readline()
        while line:            
            o.append(line)
            line = f.readline()
        if o[1][0] == "P":
            broker_commission = broker.backtesting.TradePercentage(float(o[1][1:]))  
        elif o[1][0] == "F":   
            broker_commission = pyalgotrade.broker.backtesting.FixedPerTrade(int(o[1][1:]))                 
        elif o[1][0] == "N":
            broker_commission = pyalgotrade.broker.backtesting.NoCommission()

        brk = broker.backtesting.Broker(int(o[0]), feed, broker_commission)

        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\strategy\\internal"
        sys.path.append(path)
        a = str(c)
        os.system("rename %s\\%s.md %s.py"%(path,a,a))
        module = importlib.import_module(a, package=None)   #所有內建策略
        MyStrategy = getattr(importlib.import_module(a), 'MyStrategy')

        myStrategy = MyStrategy(feed, "item",brk,y,x,z,o[2])

        sharpe_ratio = sharpe.SharpeRatio()
        mytrade = trades.Trades() 
        myStrategy.attachAnalyzer(sharpe_ratio)
        myStrategy.attachAnalyzer(mytrade)

        i = str(y)+"-"+str(x)+"-"+str(z)
        self.next(i,myStrategy,a,o,self.list_w)


    def run(self, c):

        listma = [3,5,10,22,44,66,125]
        self.list_w = []
        
        if c == "ma":
            for i in listma:    #i = listma[]裡面的值，i = 3 => i = 5
                #self.ma_th(i,c)
                trd = threading.Thread(target = self.ma_th(i,c))
                trd.start()
                

        if c == "macd":
            for x in range(2,20):      #macd ==> y,x,z
                for y in range(2,x):
                    for z in range(2,y):
                        #self.macd_th(y,x,z,c)
                        trd = threading.Thread(target = self.macd_th(y,x,z,c))
                        trd.start()



        abc = sorted(self.list_w, key=lambda list_w: float(list_w[1].replace("%","")),reverse = True)
        
        for i in range(len(abc)):
            print(abc[i])

        self.go = resultlist(abc)
        self.go.show()


    def next(self, now_list, myStrategy, a, o, list_w):

        myStrategy.run()


        #result--報酬率,o[0] == 起始資金
        result = str(((myStrategy.getResult()-int(o[0]))/int(o[0]))*100)

        in_tuple = ()                    #建立空序對
        in_tuple += (now_list,)
        in_tuple += ((result[:8]+"%"),)
        in_tuple += (myStrategy.getResult(),)
        
        list_w.append(in_tuple)

        #print("list_w=",end = "")
        #print(list_w)


        #myStrategy.info("Final portfolio value: $%.2f" % myStrategy.getResult())
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\strategy\\internal"
        try:
            self.delete_module(a)
        except:
            print("g")
        os.system("rename %s\\%s.py %s.md"%(path,a,a))


    def delete_module(self, modname, paranoid=None):
        from sys import modules
        try:
            thismod = modules[modname]
        except KeyError:
            raise ValueError(modname)
        these_symbols = dir(thismod)
        if paranoid:
            try:
                paranoid[:]  # sequence support
            except:
                raise ValueError('must supply a finite list for paranoid')
            else:
                these_symbols = paranoid[:]
        del modules[modname]
        for mod in modules.values():
            try:
                delattr(mod, modname)
            except AttributeError:
                pass
            if paranoid:
                for symbol in these_symbols:
                    if symbol[:2] == '__':  
                        continue
                    try:
                        delattr(mod, symbol)
                    except AttributeError:
                        pass

"""
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = algoWindow()
    window.show()
    sys.exit(app.exec_())
"""