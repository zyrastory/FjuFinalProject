import sys
import os

from pyalgotrade import plotter  
from pyalgotrade.stratanalyzer import returns, sharpe, drawdown, trades  
from pyalgotrade import strategy  
from pyalgotrade.bar import Frequency  
from pyalgotrade.barfeed.csvfeed import GenericBarFeed  
from pyalgotrade import broker
import pyalgotrade

import importlib
import time





def run():


    #listma = [3,5,10,22,44,66,125]

    list_w = []

    for i in range(1,365):    #i = listma[]裡面的值，i = 3 => i = 5
        feed = GenericBarFeed(Frequency.DAY, None, None)
        feed.addBarsFromCSV("item", "./aaa.csv")


        f = open("C:\\Users\\user\\Desktop\\lastest(8.19)\\setting\\setting.md")
        o=[]
        line=f.readline()
        while line:            
            o.append(line)
            line = f.readline()
        if o[1][0] == "P":
            broker_commission = broker.backtesting.TradePercentage(float(o[1][1:]))  
        elif o[1][0] == "F":   
            broker_commission = pyalgotrade.broker.backtesting.FixedPerTrade(int(o[1][1:]))                 
        elif o[1][0] == "N":
            broker_commission = pyalgotrade.broker.backtesting.NoCommission()

        brk = broker.backtesting.Broker(int(o[0]), feed, broker_commission)



        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\strategy\\internal"

        sys.path.append(path)


        a = "ma"
        #time.sleep(2)
        os.system("rename %s\\%s.md %s.py"%(path,a,a))
        module = importlib.import_module(a, package=None)   #所有內建策略
        MyStrategy = getattr(importlib.import_module(a), 'MyStrategy')
        

        #print("商品為"+listR[r])
        #print("啟用內建策略---"+a)
        myStrategy = MyStrategy(feed, "item",brk,i,o[2])

        sharpe_ratio = sharpe.SharpeRatio()
        mytrade = trades.Trades() 
        myStrategy.attachAnalyzer(sharpe_ratio)
        myStrategy.attachAnalyzer(mytrade)

        next(i,myStrategy,a,o,list_w)
    #f = open("./1.txt",'w')
    #f.write(list_w)
    #print(list_w)
    abc = sorted(list_w, key=lambda list_w: float(list_w[1].replace("%","")),reverse = True)
    
    for i in range(len(abc)):
        print(abc[i])


def next(now_list,myStrategy,a,o,list_w):

    myStrategy.run()


    #result--報酬率,o[0] == 起始資金
    result = str(((myStrategy.getResult()-int(o[0]))/int(o[0]))*100)

    in_tuple = ()                    #建立空序對
    in_tuple += (now_list,)
    in_tuple += ((result[:8]+"%"),)
    in_tuple += (myStrategy.getResult(),)
    
    list_w.append(in_tuple)

    #print("list_w=",end = "")
    #print(list_w)


    #myStrategy.info("Final portfolio value: $%.2f" % myStrategy.getResult())
    path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\strategy\\internal"
    try:
        delete_module('ma')
    except:
        print("g")
    os.system("rename %s\\%s.py %s.md"%(path,a,a))


def delete_module(modname, paranoid=None):
    from sys import modules
    try:
        thismod = modules[modname]
    except KeyError:
        raise ValueError(modname)
    these_symbols = dir(thismod)
    if paranoid:
        try:
            paranoid[:]  # sequence support
        except:
            raise ValueError('must supply a finite list for paranoid')
        else:
            these_symbols = paranoid[:]
    del modules[modname]
    for mod in modules.values():
        try:
            delattr(mod, modname)
        except AttributeError:
            pass
        if paranoid:
            for symbol in these_symbols:
                if symbol[:2] == '__':  
                    continue
                try:
                    delattr(mod, symbol)
                except AttributeError:
                    pass


run()