from pyalgotrade.stratanalyzer import returns, sharpe, drawdown, trades  
from pyalgotrade import strategy  
from pyalgotrade.bar import Frequency  
from pyalgotrade.barfeed.csvfeed import GenericBarFeed
from pyalgotrade import broker
import pyalgotrade
import os
import importlib
import sys

def compilerstrategy(self):
	feed = GenericBarFeed(Frequency.DAY, None, None)
	feed.addBarsFromCSV("item", "./strategy/8-11.csv")

	f = open("./setting/setting.md")
	o=[]
	line=f.readline()
	while line:            
	    o.append(line)
	    line = f.readline()
	if o[1][0] == "P":
	    broker_commission = broker.backtesting.TradePercentage(float(o[1][2:]))  
	elif o[1][0] == "F":   
	    broker_commission = pyalgotrade.broker.backtesting.FixedPerTrade(int(o[1][1:]))                 
	elif o[1][0] == "N":
	    broker_commission = pyalgotrade.broker.backtesting.NoCommission()
	brk = broker.backtesting.Broker(int(o[0]), feed, broker_commission)


	os.system("rename .\\cache\\compiler.md compiler.py")
	sys.path.append('C:\\Users\\user\\Desktop\\lastest(8.19)\\cache')


	module = importlib.import_module("compiler", package=None)
	MyStrategy = getattr(importlib.import_module("compiler"), 'MyStrategy')

	print("編譯程序啟用")
	delete_module("compiler")
	myStrategy = MyStrategy(feed, "item",brk)
	#print("編譯程序啟用2")
	sharpe_ratio = sharpe.SharpeRatio()
	mytrade = trades.Trades() 
	myStrategy.attachAnalyzer(sharpe_ratio)
	myStrategy.attachAnalyzer(mytrade)
	myStrategy.run()

	os.system("rename .\\cache\\compiler.py compiler.md")

def delete_module(modname, paranoid=None):
    from sys import modules
    try:
        thismod = modules[modname]
    except KeyError:
        raise ValueError(modname)
    these_symbols = dir(thismod)
    if paranoid:
        try:
            paranoid[:]  # sequence support
        except:
            raise ValueError('must supply a finite list for paranoid')
        else:
            these_symbols = paranoid[:]
    del modules[modname]
    for mod in modules.values():
        try:
            delattr(mod, modname)
        except AttributeError:
            pass
        if paranoid:
            for symbol in these_symbols:
                if symbol[:2] == '__':  # ignore special symbols
                    continue
                try:
                    delattr(mod, symbol)
                except AttributeError:
                    pass