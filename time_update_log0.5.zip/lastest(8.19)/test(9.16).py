import pymysql

mydb= pymysql.connect(host='localhost', port=3306, user='root', passwd='12345', db ='log',charset='UTF8')
cur = mydb.cursor()


#cur.execute('SELECT*FROM test')
#sql = "DELETE FROM test"
sql2 ="INSERT INTO test(item_name,ts_name,ni,gp,gl,tt,pc,tz) VALUES ('雞雞','策略',2500,3000,-50,10,4,50000)"
#sql ="INSERT INTO test(item_name) VALUES ('1500');"
#sql ="DELETE FROM test WHERE ni = 2500 LIMIT 1"

#cur.execute(sql)
cur.execute(sql2)

#rows=cur.fetchall()

#print(rows[0][0])
mydb.commit()