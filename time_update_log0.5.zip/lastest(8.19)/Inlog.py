import pymysql
from datetime import datetime

def inlog(name,ts_name,mytrade,myStrategy):
	#now= datetime.now()
	now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

	mydb= pymysql.connect(host='localhost', port=3306, user='root', passwd='12345', db ='log',charset='UTF8')
	cur = mydb.cursor()

	gross_w =mytrade.getProfits().sum()
	gross_l =mytrade.getLosses().sum()

	try:
		rate = str(mytrade.getProfitableCount()/mytrade.getCount()*100)[:6]
	except:
		rate = 0

	#print("rate",rate)
	#print("\n\n\n\n\n")
	sql ="INSERT INTO history(nowtime,name,tsname,grossWin,grossLose,winrate) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}')"\
	.format(now,name,ts_name,int(gross_w),int(gross_l),rate)

	cur.execute(sql)
	mydb.commit()

	cur.close()

