import requests
#from bs4 import BeautifulSoup 
import sys
import json
import time
import pymysql
import csv

from inmysql import tocsv
from datetime import datetime


url = "http://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&"

def test(num):
    now = datetime.now()

    dic = {"台泥":1101, "中石化":1314}
    d = dic[num]
    dic1 = {1101:'aaa', 1314:'bbb'}
    t = dic1[d]

    #x = "Date Time,Open,High,Low,Close,Volume"+"\n"
    mydb= pymysql.connect(host='localhost', port=3306, user='root', passwd='12345', db ='stock',charset='UTF8')
    cur = mydb.cursor()
    sql_check = "SELECT*FROM %s"%t
    cur.execute(sql_check)
    row = cur.fetchall()
    for row in row:
        year = int(str(row[0])[:4])
        month = str(row[0])[5:7]


    if month[0]=="0":
        i = int(month[1])
    else:
        i = int(month)

    print(i)
    x = ""
    for year in range(year,now.year+1):
        if year != year:
            i=1
        print("i2 =",i)
        for month in range(i,13):
            if month<10:
                month = "0"+str(month)
            setting="date="+str(year)+str(month)+"01&stockNo="+str(d)

            headers = {
                'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36    '
            }
            url_new = url + setting

            res = requests.get(url_new,headers=headers)

            zyra=(res.text.encode(sys.stdin.encoding, "replace").decode(sys.stdin.encoding))
            
            js=json.loads(zyra)

            #print(js['fields'])
            abc = []
            try:
                for js['data'] in js['data']:
                    #print(js['data'])
                    abc.append(js['data'])
            except:
                break
            #print(type(zyra))
            #print(zyra['data'])
            
            for a in abc:
                list_need=[0,3,4,5,6,1]

                for i in list_need:
                    if a[1] == "0":
                        break 
                
                    else:   

                        if i == 1:
                            x+=(a[i].replace(",","")+"\n")
                        elif i ==0:
                            x+=((str(int(a[i][:3])+1911)+a[i][3:])+",")
                        else:
                            x+=(a[i].replace(",","")+",")

            time.sleep(2)
                

    with open("test.csv" , 'w', encoding='UTF-8') as w:
        w.write(x)

    tocsv(d)

#test()