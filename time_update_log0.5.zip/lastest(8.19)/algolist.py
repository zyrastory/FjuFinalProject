import os
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *


class resultlist(QWidget):
	def __init__(self, abc, parent = None):
		super(resultlist, self).__init__(parent)

		self.tableWidget = QTableWidget()
		self.table(abc)

		hhbox = QHBoxLayout()
		hhbox.addWidget(self.tableWidget)
		self.setLayout(hhbox)

		self.setWindowTitle("演算法前三名")
		self.setWindowIcon(QIcon("icon.png"))
		self.resize(400, 150)

	def table(self, abc):
		self.tableWidget.setRowCount(3)
		self.tableWidget.setColumnCount(3)

		self.setStyleSheet("font-size: 12pt") 
		self.tableWidget.setHorizontalHeaderLabels(["參數","報酬率","profolio"])

		for i in range(3):
			for j in range(3):
				a = QLabel(str(abc[i][j]))
				self.tableWidget.setCellWidget(i,j,a)



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = resultlist()
    window.show()
    sys.exit(app.exec_())
