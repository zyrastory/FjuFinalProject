import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import os

from notepad import Writer, Notepad
from ta_test8_6 import Figure_Canvas
from report5 import tab_widget
from datewrong import dateWrong
from place_order import Window
from algo import algoWindow
from Insql import insql
from stockcrawler import test

sys.path.append('C:\\Users\\user\\Desktop\\lastest(8.19)\\game')
import tetris
from tetris import Tetris
import Snake
from Snake import MyApp


class firstWindow(QWidget):

    def setupUi(self,MainWindow):
        #sshFile="orange.qss"
        #with open(sshFile,"r") as fh:
        #    self.setStyleSheet(fh.read())
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1024, 768)
        #MainWindow.setStyleSheet("#MainWindow { border-image: url(./icon/trader2.png) 0 0 0 0 stretch stretch; }")
        self.setWindowIcon(QIcon('./icon/cola.png')) 
        self.central_widget = QStackedWidget()
        self.setCentralWidget(self.central_widget)               
        self.show()
        
    def fade(self):
        if self.fileMenu.title()=="商品":
            self.fileMenu.setTitle("Item")
            self.addAction.setText("Add Item")
            self.addAction.setStatusTip('Add item from database')
            self.setAction.setText("Item Setting")
            self.setAction.setStatusTip('Set selected item')
            self.updateAction.setText("Update Item")
            self.updateAction.setStatusTip('Update item choosen to lastest')
            self.fileMenu2.setTitle("Strategy")
            self.writeAction.setText("Edit")
            self.writeAction.setStatusTip('Write Strategy')
            self.chooseAction.setText("Choose")
            self.chooseAction.setStatusTip('Choose strategy want to use')
            self.algoAction.setText("Algorithm")
            self.algoAction.setStatusTip('Parameter Optimization')
            self.fileMenu3.setTitle("Performance Report")
            self.reportAction.setText("Show")
            self.reportAction.setStatusTip('Show the Performance Report')
            self.fileMenu4.setTitle("Order")
            self.exchangeAction.setText("Stock Exchange")
            self.exchangeAction.setStatusTip('Choose Stock Exchange')
            self.orderAction.setText("Make Order")
            self.orderAction.setStatusTip('Make Order with Stock Exchange')
            self.fileMenu5.setTitle("Advanced")
            self.fileMenu6.setTitle("Language Setting")
            self.fileMenu6.setTitle("Language Setting")
            self.fileMenu7.setTitle("Game")
            self.gameAction.setText("Tetris")
            self.snakeAction.setText("Snake eating")
            self.initset.setText("Initial Setting")


    def fadeout(self):
        if self.fileMenu.title()=="Item":
            self.fileMenu.setTitle("商品")
            self.addAction.setText("新增商品")
            self.addAction.setStatusTip('從內部資料庫新增商品')
            self.setAction.setText("設定商品")
            self.setAction.setStatusTip('設定目前商品的細項')
            self.updateAction.setText("更新商品")
            self.updateAction.setStatusTip('將所選商品更到最新')
            self.fileMenu2.setTitle("交易策略")
            self.writeAction.setText("編寫")
            self.writeAction.setStatusTip('手動編寫交易策略')
            self.chooseAction.setText("選擇")
            self.chooseAction.setStatusTip('選擇欲使用之交易策略')
            self.algoAction.setText("演算法")
            self.algoAction.setStatusTip('程式最佳化')
            self.fileMenu3.setTitle("檢視績效報告")
            self.reportAction.setText("策略績效報告")
            self.reportAction.setStatusTip('檢視此次交易策略之績效報告')
            self.fileMenu4.setTitle("下單接口")
            self.exchangeAction.setText("選擇證券交易所")
            self.exchangeAction.setStatusTip('選擇欲交易之證券交易所')
            self.orderAction.setText("下單")
            self.orderAction.setStatusTip('與證券交易所進行交易')
            self.fileMenu5.setTitle("進階")
            self.fileMenu6.setTitle("設定語言")
            self.fileMenu7.setTitle("遊戲")
            self.gameAction.setText("俄羅斯方塊")
            self.snakeAction.setText("貪吃蛇")
            self.initset.setText("初始設定")

    def set_timer(self):
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"
        listS = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listS.append(f)  
        if len(listS)>=1:
            self.setAction.setDisabled(False)
            self.chooseAction.setDisabled(False)
        else:
            self.setAction.setDisabled(True)
            self.chooseAction.setDisabled(True)
        QTimer.singleShot(10, self.set_timer)
            
    def report_timer(self):
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"
        listR = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listR.append(f)        
        for r in range(len(listR)):
            if int(listR[r][0])>=1:
                self.reportAction.setDisabled(False)
            else:
                self.reportAction.setDisabled(True)
        if len(listR)==0:
            self.reportAction.setDisabled(True)
                         
        QTimer.singleShot(10, self.report_timer)

    def re(self):
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"
        listR = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listR.append(f)

        if len(listR) == 0:
            if self.fileMenu.title()=="Item":
                self.dwrongmsg = dateWrong("NE",1)
            else:
                self.dwrongmsg = dateWrong("NE")
            self.dwrongmsg.show()

        for r in range(len(listR)):
            if int(listR[r][0])>=1:                 # 1 -- 前綴,判斷是否有選擇策略
                self.reportwindow = tab_widget()    # initial report畫面,跳轉report5
                self.reportwindow.show()
                #break

            elif r == len(listR)-1:
                if self.fileMenu.title()=="Item":
                    self.dwrongmsg = dateWrong("NS-C",1)  #no strategy choose
                else:
                    self.dwrongmsg = dateWrong("NS-C")
                self.dwrongmsg.show()

    def se(self):      
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"

        listC = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                #listC.append(f.replace(".csv",""))
                listC.append(f.rstrip(".csv"))

        if len(listC)>=1:                     #判斷是path底下是否有csv -->是否有商品
            print("choose--判斷csv:",end="")
            print (listC) 
            
            if self.fileMenu.title()=="Item":
                self.choosewindow = chooseWindow(1)
            else:
                self.choosewindow = chooseWindow()
            self.central_widget.addWidget(self.choosewindow)
            self.central_widget.setCurrentWidget(self.choosewindow)
        else:
            if self.fileMenu.title()=="Item":
                self.dwrongmsg = dateWrong("NI-C",1)
            else:
                self.dwrongmsg = dateWrong("NI-C")  #no item choose
            self.dwrongmsg.show()

    def ye(self):       #單次設定商品，確認底下的csv並顯示

        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"

        listC = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listC.append(f.rstrip(".csv"))

        if len(listC)>=1:
            if self.fileMenu.title()=="Item":
                self.setwindow = setWindow(1)
            else:
                self.setwindow = setWindow()

            self.central_widget.addWidget(self.setwindow)
            self.central_widget.setCurrentWidget(self.setwindow)

        else:    #listC = csv 的數量，不大於1表示沒有商品
            if self.fileMenu.title()=="Item":
                self.dwrongmsg = dateWrong("NI-CF",1)
            else:
                self.dwrongmsg = dateWrong("NI-CF")  #no item choose
            self.dwrongmsg.show()
    
    def ae(self):

        if self.fileMenu.title()=="Item":
            self.addwindow = addWindow(1)
        else:
            self.addwindow = addWindow()

        self.central_widget.addWidget(self.addwindow)
        self.central_widget.setCurrentWidget(self.addwindow)
        self.setCentralWidget(self.central_widget)

    def ue(self):
        self.updatewindow = updateWindow()
        self.central_widget.addWidget(self.updatewindow)
        self.central_widget.setCurrentWidget(self.updatewindow)
    
    def we(self):       #init editor and compiler
        self.writewindow = Writer()
        self.writewindow.show()

    def Russia(self):
        self.abc =Tetris()
        self.abc.show()

    def EAT(self):
        self.eat = MyApp()
        self.eat.show()

    def in_w(self):
        if self.fileMenu.title()=="Item":
            self.initsetWindow = InisetWindow(1)
        else:
            self.initsetWindow = InisetWindow()
        self.initsetWindow.show()

    def al(self):
        self.algowindow = algoWindow()
        self.algowindow.show()

    def ex(self):
        self.exchangewindow = exchangeWindow()
        self.exchangewindow.show()

    def initUI(self):
     
        self.addAction = QAction(QIcon('./icon/b_a.png'), '新增商品', self)
        self.addAction.setShortcut('Alt+F1')
        self.addAction.setStatusTip('從內部資料庫新增商品')
        self.addAction.triggered.connect(self.ae)

        self.setAction = QAction(QIcon('./icon/b_set.png'), '設定商品', self)
        self.setAction.setShortcut('Alt+F2')
        self.setAction.setDisabled(True)
        self.setAction.triggered.connect(self.ye)
        self.setAction.setStatusTip('設定目前商品的細項')

        self.updateAction = QAction(QIcon('./icon/b_up.png'),'更新商品', self)
        self.updateAction.setShortcut('Alt+F3')
        self.updateAction.triggered.connect(self.ue)
        self.updateAction.setStatusTip('將所選商品更到最新')


        #第二個按鈕裡面的東西  
        self.writeAction = QAction(QIcon('./icon/b_write.png'), '編寫', self)
        self.writeAction.setShortcut('Alt+W')
        self.writeAction.triggered.connect(self.we)
        self.writeAction.setStatusTip('手動編寫交易策略')


        self.chooseAction = QAction(QIcon('./icon/b_cho.png'), '選擇', self)
        self.chooseAction.setShortcut('Alt+C')

        self.chooseAction.triggered.connect(self.se)
        self.chooseAction.setStatusTip('選擇欲使用之交易策略')
        
        self.algoAction = QAction(QIcon('./icon/b_wor.png'),'演算法',self)
        self.algoAction.setShortcut('Alt+A')
        self.algoAction.setStatusTip('程式最佳化')
        self.algoAction.triggered.connect(self.al)

        #第三個按鈕
        self.reportAction = QAction(QIcon('./icon/b_re.png'), '策略績效報告', self)
        self.reportAction.setShortcut('Alt+R')
        self.reportAction.setStatusTip('檢視此次交易策略之績效報告')
        self.reportAction.setDisabled(True)
        self.reportAction.triggered.connect(self.re)        
        #第四個按鈕
        self.exchangeAction = QAction(QIcon('./icon/b_exc.png'), '選擇證券交易所', self)
        self.exchangeAction.setShortcut('Alt+X')
        self.exchangeAction.triggered.connect(self.ex)
        self.exchangeAction.setStatusTip('選擇欲交易之證券交易所')

        self.orderAction = QAction(QIcon('./icon/b_ord.png'), '下單', self)
        self.tradewindow = Window()
        self.orderAction.setShortcut('Alt+O')
        self.orderAction.triggered.connect(self.tradewindow.show)
        self.orderAction.setStatusTip('與證券交易所進行交易')
        #第五個按鈕
        
        self.Language = QAction('繁體中文', self)
        self.Language.setShortcut('Alt+8')
        self.Language.triggered.connect(self.fadeout)
        self.Language2 = QAction('English', self)
        self.Language2.setShortcut('Alt+9')
        self.Language2.triggered.connect(self.fade)

        
        self.gameAction = QAction('俄羅斯方塊', self)
        self.gameAction.triggered.connect(self.Russia)

        self.snakeAction = QAction('貪吃蛇', self)
        self.snakeAction.triggered.connect(self.EAT)

        self.initset = QAction(QIcon('./icon/b_setup.png'),'初始設定', self)
        self.initset.setShortcut('Alt+0')
        self.initset.triggered.connect(self.in_w)


        self.statusBar()
        menubar = self.menuBar()
        menubar.setStyleSheet("font-size: 12pt")
        self.setStyleSheet("""QMenuBar {
        width: 185px;font-size: 12pt}
       """)
        
        self.fileMenu = menubar.addMenu('商品')
        self.fileMenu2 = menubar.addMenu('交易策略')
        self.fileMenu3 = menubar.addMenu('檢視績效報告')
        self.fileMenu4 = menubar.addMenu('下單接口')
        self.fileMenu5 = menubar.addMenu('進階')
        self.fileMenu6 = self.fileMenu5.addMenu(QIcon('./icon/b_lang.png'),'設定語言')
        self.fileMenu7 = self.fileMenu5.addMenu(QIcon('./icon/b_game.png'),'遊戲')
        
        self.fileMenu.addActions([self.addAction,self.setAction,self.updateAction])
        self.fileMenu2.addActions([self.writeAction,self.chooseAction,self.algoAction])
        self.fileMenu3.addAction(self.reportAction)
        self.fileMenu4.addActions([self.exchangeAction,self.orderAction])
        self.fileMenu5.addActions([self.initset])
        self.fileMenu6.addActions([self.Language,self.Language2])
        self.fileMenu7.addActions([self.gameAction,self.snakeAction])

        self.setWindowTitle('iTrader')
        self.createContextMenu()
        self.report_timer()
        self.set_timer()
        
        self.toolbar = QToolBar(self)
        self.addToolBar(QtCore.Qt.LeftToolBarArea,self.toolbar)
        
        Action_list = [self.addAction,self.setAction,self.chooseAction,self.reportAction]
        self.toolbar.addActions(Action_list)
        
        self.toolbar.setMovable(False)
        self.toolbar.setIconSize(QtCore.QSize(70,70))
        self.toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon|QtCore.Qt.AlignLeading)

        self.show()

    def createContextMenu(self):  

        self.setContextMenuPolicy(Qt.CustomContextMenu)  
        self.customContextMenuRequested.connect(self.showContextMenu)  
  
        self.contextMenu = QMenu(self)  

        action_list = [self.addAction,self.writeAction,self.chooseAction,self.reportAction]
        for a in action_list:
            self.contextMenu.addAction(a)
            self.contextMenu.addSeparator()

    def showContextMenu(self, pos):  

        self.contextMenu.move(self.pos() + pos)  
        self.contextMenu.show()  
 


    def main():
        app = QApplication(sys.argv)
        mainwindow = MainWindow()
        mainwindow.show()

class addWindow(QTabWidget):
    def __init__(self,*args, parent = None):
        super(addWindow, self).__init__(parent)
        self.setWindowTitle('新增商品')

        self.listWidget = QListWidget(self)
        self.listWidget2 = QListWidget(self)
        self.listWidget3 = QListWidget(self)

        item = QtWidgets.QListWidgetItem()
        item2 = QtWidgets.QListWidgetItem()
        item3 = QtWidgets.QListWidgetItem()
        if len(args) == 0:          # delimiter
            item.setText('商品'+'\t'*2+'說明\n'+'-'*53)
            item2.setText('商品'+'\t'*2+'說明\n'+'-'*53)
            item3.setText('商品'+'\t'*2+'說明\n'+'-'*53)
            self.start = QLabel("起始",self)
            self.end = QLabel("結束",self)
            self.k = QLabel("K線週期",self)
        
        else:
            self.setWindowTitle('Add item')
            item.setText('item'+'\t'*2+'Description\n'+'-'*53)
            item2.setText('item'+'\t'*2+'Description\n'+'-'*53)
            item3.setText('item'+'\t'*2+'Description\n'+'-'*53)
            self.start = QLabel("Strat",self)
            self.end = QLabel("End",self)
            self.k = QLabel("K-Line",self)
        
        
        item.setFlags(QtCore.Qt.NoItemFlags)        # item should not be selectable
        self.listWidget.addItem(item)
        self.listWidget.addItems(["%-20s%10s"%("中石化","中國石油化工股份有限公司"), \
            "%-20s%10s"%("台泥","台灣水泥"),"%-20s%10s"%("富邦"," 富邦集團"),\
            "%-20s%10s"%("統一","統一企業"),"%-20s%10s"%("亞聚","亞洲聚合股份有限公司"),\
            "%-20s%10s"%("中鋼","中國鋼鐵股份有限公司")])
        self.listWidget.setFixedSize(330,200)
        
        
        self.listWidget2.addItem(item2)
        self.listWidget2.addItems(["%-20s%10s"%("TWSEAUTO","汽車"), \
            "%-20s%10s"%("TWSECEM","水泥"),"%-20s%10s"%("TWSECON"," 營造建材"),\
            "%-20s%10s"%("TWSEFOOD","食品"),"%-20s%10s"%("TWSERUB","橡膠"),\
            "%-20s%10s"%("TWSESTEE","鋼鐵")])
        self.listWidget2.setFixedSize(330,200)
        
        
        self.listWidget3.addItem(item3)
        self.listWidget3.addItems(["%-20s%10s"%("EXF1","電指期"), \
            "%-20s%10s"%("FXF1","金指期"),"%-20s%10s"%("MXF1","小台期"),\
            "%-20s%10s"%("TXF1","台指期")])
        self.listWidget3.setFixedSize(330,200)
        
        if len(args) == 0:
            self.addTab(self.listWidget,"股票")
            self.addTab(self.listWidget2,"指數")
            self.addTab(self.listWidget3,"期貨")
        else:
            self.addTab(self.listWidget,"stock")
            self.addTab(self.listWidget2,"index")
            self.addTab(self.listWidget3,"futures")
        self.year = QComboBox(self)
        self.month = QComboBox(self)
        self.day = QComboBox(self)
        self.year2 = QComboBox(self)
        self.month2 = QComboBox(self)
        self.day2 = QComboBox(self)
        self.scope = QLineEdit(self)
        self.Tcount = QComboBox(self)


        self.year.addItems([str(x) for x in range(1998,2018)])

        #self.year.itemText(0).setFlags(Qt.NoItemFlags)
        #self.year.setItemData(1,Qt.NoItemFlags)#.setEnabled(False)
        #self.year.setEnabled(False)
        #AllItems = [self.year.itemText(i) for i in range(self.year.count())]

        self.month.addItems([str(y) for y in range(1,13)])
        self.day.addItems([str(z) for z in range(1,32)])
        self.year2.addItems([str(a) for a in range(1998,2018)])
        self.year2.setCurrentIndex(self.year2.count()-1)
        self.month2.addItems([str(b) for b in range(1,13)])
        self.month2.setCurrentIndex(self.month2.count()-1)
        self.day2.addItems([str(c) for c in range(1,32)])

        self.scope.setPlaceholderText("default:1")  #時間週期輸入框，設定字體大小
        f = self.scope.font()
        f.setPointSize(12) 
        self.scope.setFont(f)

        if len(args) == 0:
            self.Tcount.addItems(["日","周","月"])
            self.subbutton = QPushButton('確認',self)
            backbutton = QPushButton('返回',self)
            
        else:
            self.Tcount.addItems(["Day","Week","Month"])
            self.subbutton = QPushButton('Ok',self)
            backbutton = QPushButton('Back',self)

        self.Tcount.resize(40,27.5)
        self.start.move(350,110)    #起始時間標籤
        self.year.move(400, 100)
        self.year.resize(100,25)
        self.month.move(500, 100)
        self.month.resize(100,25)
        self.day.move(600, 100)
        self.day.resize(100,25)

        self.end.move(350,160)  #結束時間標籤
        self.year2.move(400,150)
        self.year2.resize(100,25)
        self.month2.move(500,150)
        self.month2.resize(100,25)
        self.day2.move(600,150)
        self.day2.resize(100,25)
        
        self.k.move(350,210)
        self.scope.move(430,200)
        self.scope.resize(100,25)
        self.Tcount.move(500,200)
        self.Tcount.resize(50,25)

        
        self.subbutton.move(450, 350) 
        backbutton.move(550, 350)

        self.lineedit = QLineEdit(self)
        model = QStringListModel()
        model.setStringList(['中石化','台泥','富邦','統一','亞聚'\
            ,'中鋼','TWSEAUTO','TWSECEM','TWSECON','TWSEFOOD','TWSERUB','TWSESTEE','EXF1','FXF1','MXF1','TXF1'])

        completer = QCompleter()
        completer.setModel(model)
        self.lineedit.setCompleter(completer)
        self.lineedit.setFixedWidth(200)
        self.lineedit.setPlaceholderText("search by name")
        f = self.lineedit.font()
        f.setPointSize(12) 
        self.lineedit.setFont(f)
        self.lineedit.move(350, 50)

        self.subbutton.clicked.connect(lambda:self.compare(self.currentIndex(),len(args))) # 比較如果時間不符跳警示窗
        backbutton.clicked.connect(self.close)

        self.bigtimer()
        self.yeartimer()
        self.space = self.lineedit.text()


    def bigtimer(self):
        try:
            self.listWidget.selectedItems()[0].text()
            self.timer()
        except:
            QTimer.singleShot(10, self.smalltimer)

    def smalltimer(self):
        if self.lineedit.text() != self.space:
            self.realtimer()
        else:
            QTimer.singleShot(10, self.bigtimer)

    def timer(self):
        try:
            self.listWidget.selectedItems()[0].text()
            self.clear_text()
            self.realtimer()          
        except:
            QTimer.singleShot(10, self.timer)
    
    def realtimer(self):

        if self.lineedit.text() != self.space:
            self.clear(self.listWidget)
            self.timer()
        else:
            QTimer.singleShot(10, self.realtimer)
    
    def clear(self,listwidget):
        listwidget.clearSelection()


    def clear_text(self):
        self.lineedit.clear()

    def yeartimer(self):
        now_year = int(self.year.currentText())
        end_year = int(self.year2.currentText())
        now_month = int(self.month.currentText())
        end_month = int(self.month2.currentText())
        list30 = [4,6,9,11]

        for i in range(self.year2.count()):
            if int(self.year2.itemText(i))< now_year:
                self.year2.setItemData(i, 0, Qt.UserRole - 1)
            else:
                self.year2.setItemData(i, -1, Qt.UserRole - 1)

        if now_year == end_year:
            for j in range(self.month2.count()):
                if int(self.month2.itemText(j))<now_month:
                    self.month2.setItemData(j, 0, Qt.UserRole - 1)
                else:
                    self.month2.setItemData(j, -1, Qt.UserRole - 1)
        else:
            for j in range(self.month2.count()):
                self.month2.setItemData(j, -1, Qt.UserRole - 1)

        if now_month in list30:
            self.day.setItemData(28, -1, Qt.UserRole - 1)
            self.day.setItemData(29, -1, Qt.UserRole - 1)
            self.day.setItemData(30, 0, Qt.UserRole - 1)
        elif now_month == 2:
            if now_year%4 != 0 or now_year%100 == 0 and now_year%400 != 0:  #平年
                self.day.setItemData(28, 0, Qt.UserRole - 1)
                self.day.setItemData(29, 0, Qt.UserRole - 1)
                self.day.setItemData(30, 0, Qt.UserRole - 1)
            elif now_year%4 == 0 and now_year%100 != 0 or now_year%400 ==0:
                self.day.setItemData(28, -1, Qt.UserRole - 1)
                self.day.setItemData(29, 0, Qt.UserRole - 1)
                self.day.setItemData(30, 0, Qt.UserRole - 1)
        else:
            self.day.setItemData(28, -1, Qt.UserRole - 1)
            self.day.setItemData(29, -1, Qt.UserRole - 1)
            self.day.setItemData(30, -1, Qt.UserRole - 1)

        if end_month in list30:
            self.day2.setItemData(28, -1, Qt.UserRole - 1)
            self.day2.setItemData(29, -1, Qt.UserRole - 1)
            self.day2.setItemData(30, 0, Qt.UserRole - 1)
        elif end_month == 2:
            if end_year%4 != 0 or end_year%100 == 0 and end_year%400 != 0:  #平年
                self.day2.setItemData(28, 0, Qt.UserRole - 1)
                self.day2.setItemData(29, 0, Qt.UserRole - 1)
                self.day2.setItemData(30, 0, Qt.UserRole - 1)
            elif end_year%4 == 0 and end_year%100 != 0 or end_year%400 ==0:
                self.day2.setItemData(28, -1, Qt.UserRole - 1)
                self.day2.setItemData(29, 0, Qt.UserRole - 1)
                self.day2.setItemData(30, 0, Qt.UserRole - 1)
        else:
            self.day2.setItemData(28, -1, Qt.UserRole - 1)
            self.day2.setItemData(29, -1, Qt.UserRole - 1)
            self.day2.setItemData(30, -1, Qt.UserRole - 1)

        QTimer.singleShot(10, self.yeartimer)

    def compare(self,index,args_count):
        a = None
        itemlist = (['中石化','台泥','富邦','統一','亞聚'\
            ,'中鋼','TWSEAUTO','TWSECEM','TWSECON','TWSEFOOD','TWSERUB','TWSESTEE','EXF1','FXF1','MXF1','TXF1'])
        if index == 0:
            mylist = self.listWidget
        elif index == 1:
            mylist = self.listWidget2
        elif index == 2:
            mylist = self.listWidget3 
        
        for i in mylist.selectedItems():
            a = i.text()

        if a == None and self.lineedit.text().rstrip() == "":
            if args_count == 0:
                self.dwrongmsg = dateWrong("NE") # no enter
            else:
                self.dwrongmsg = dateWrong("NE",1)
            self.dwrongmsg.show()

        elif a == None and self.lineedit.text() not in itemlist:
            if args_count == 0:
                self.dwrongmsg = dateWrong("NI")  #no item
            else:
                self.dwrongmsg = dateWrong("NI",1)
            self.dwrongmsg.show()
        
        elif int(self.year.currentText()) > int(self.year2.currentText()):
            self.dwrongmsg = dateWrong("T")   #time error
            print ("date wrong1")
            self.dwrongmsg.show()
        elif int(self.year.currentText()) == int(self.year2.currentText()) and int(self.month.currentText()) >= \
            int(self.month2.currentText()):
            self.dwrongmsg = dateWrong("T")
            print ("date wrong2")
            self.dwrongmsg.show()

        else:
            print ("date right")
            self.tt(index)
            self.close()
        

    def tt(self,index):
        if index == 0:
            try:
                self.num = str(self.listWidget.selectedItems()[0].text()[:3].replace(" ",""))
            except:
                self.num = self.lineedit.text()
        elif index == 1:
            try:
                self.num = str(self.listWidget2.selectedItems()[0].text()[:8].replace(" ",""))
            except:
                self.num = self.lineedit.text()
        elif index == 2:
            try:
                self.num = str(self.listWidget3.selectedItems()[0].text()[:5].replace(" ",""))
            except:
                self.num = self.lineedit.text()


        print("stockcombo is "+self.num)
        if self.scope.text().rstrip()=="":    #如果沒有輸入時間週期，跑預設的1
            self.num2=1
        else:
            self.num2 = int(self.scope.text())
        self.a = str(self.year.currentText())+"-"+str(self.month.currentText())+"-"+str(self.day.currentText())
        self.b = str(self.year2.currentText())+"-"+str(self.month2.currentText())+"-"+str(self.day2.currentText())
        if self.Tcount.currentText() == "日" or self.Tcount.currentText() == "Day":
            self.tc = self.num2* 1

        elif self.Tcount.currentText() == "周" or self.Tcount.currentText() == "Week":
            self.tc = self.num2* 7
        
        else:
            self.tc = self.num2* 30            
        print("self.num="+self.num)
        print("self.a="+self.a)
        print("self.b="+self.b)
        print("self.tc="+str(self.tc))

        self.kline(self.num,self.a,self.b,self.tc)

    
    def main():
        app = QApplication(sys.argv)
        mainwindow = MainWindow()
        mainwindow.show()
        

    def kline(self,num,a,b,tc):
             
        self.dr = Figure_Canvas() #實例化一个FigureCanvas
        self.dr.test(num,a,b,tc)  # 畫圖
        self.dr.show()


class setWindow(QWidget):
    def __init__(self,*args, parent = None):
        super(setWindow, self).__init__(parent)
        self.setFixedSize(700, 300)
        self.setWindowTitle('設定商品')

        self.IL = QListWidget(self)
        self.IL.setFixedSize(240,200)
        self.IL.move(50,35)

        dic = {"aaa":'台泥', "bbb":'中石化', "ccc":'富邦', "ddd":'統一', "eee":'亞聚', "fff":'中鋼'
    , "ggg":'TWSEAUTO',"hhh":'TWSECEM',"iii":'TWSECON',"jjj":'TWSEFOOD',"kkk":'TWSERUB',"lll":'TWSESTEE'
    ,"mmm":'EXF1',"nnn":'FXF1',"ooo":'MXF1',"ppp":'TXF1'}
        
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"
        listI = []
        listJ = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listI.append(f[2:].rstrip(".csv"))


        for i in range(len(listI)):
            for p in dic:
                if listI[i].find(p) != -1:
                    listI[i] = listI[i].replace(p,dic[p])
            
        self.IL.addItems(listI)

        if len(args) == 0:
            strategybutton = QPushButton('確認',self)
            money = QLabel('初始資金',self)
            hand = QLabel('手續費',self)
            count = QLabel('股數',self)
            self.groupBox = QGroupBox('沒有手續費',self)
            self.groupBox2 = QGroupBox('固定',self)
            self.groupBox3 = QGroupBox('按交易金額比例(%)',self)
            strategybutton.clicked.connect(lambda:self.compare2(0))
        else:
            strategybutton = QPushButton('Ok',self)
            money = QLabel('Initial capital',self)
            hand = QLabel('Commission',self)
            count = QLabel('Number of shares\nper transaction',self)
            self.groupBox = QGroupBox('No Commission',self)
            self.groupBox2 = QGroupBox('Fixed',self)
            self.groupBox3 = QGroupBox('percent',self)
            strategybutton.clicked.connect(lambda:self.compare2(1))


        strategybutton.move(120, 220)
        strategybutton.resize(70,50)
        money.move(350,35)
        hand.move(350,120)
        count.move(350,210)

        self.edit1 = QLineEdit(self)
        self.edit1.move(450,35)
   
   
        self.groupBox.setCheckable(True)
        self.groupBox.setChecked(True)
        self.groupBox2.setCheckable(True)
        self.groupBox2.setChecked(False)

        self.fix = QLineEdit(self)
        grid = QGridLayout()
        grid.addWidget(self.fix,0,0)
        self.groupBox2.setLayout(grid)

        self.groupBox3.setCheckable(True)
        self.groupBox3.setChecked(False)

        self.per = QLineEdit(self)
        grid = QGridLayout()
        grid.addWidget(self.per,0,0)
        self.groupBox3.setLayout(grid)

        self.groupBox.move(450,70)
        self.groupBox2.move(450,90)
        self.groupBox3.move(450,140)

        self.edit3 = QLineEdit(self)
        self.edit3.move(450,210)

        self.init()
        self.haha()


    def st(self):

        if self.edit1.text()=="":
            num1 = self.o[0].strip("\n")

        else:
            num1 = self.edit1.text()

        
        if self.groupBox.isChecked() != True:
            if self.groupBox2.isChecked() != True:
                if self.groupBox3.isChecked() != True:
                    num2 = self.o[1].strip("\n")
        
        if  self.fix.text() !="" and self.groupBox2.isChecked() ==True:
            num2 = "F"+self.fix.text()
        elif self.per.text() !=""and self.groupBox3.isChecked() ==True:
            num2 = "P"+str(float(self.per.text())*0.01)
        else:
            num2 = "N"
        if self.edit3.text()=="":
            num3 = self.o[2]
        else:
            num3 = self.edit3.text()

        dic = {"台泥":'aaa', "中石化":'bbb', "富邦":'ccc', "統一":'ddd', "亞聚":'eee', "中鋼":'fff'
    , "TWSEAUTO":'ggg',"TWSECEM":'hhh',"TWSECON":'iii',"TWSEFOOD":'jjj',"TWSERUB":'kkk',"TWSESTEE":'lll'
    ,"EXF1":'mmm',"FXF1":'nnn',"MXF1":'ooo',"TXF1":'ppp'}

        
        for q in dic:
            if self.IL.selectedItems()[0].text().find(q) != -1:
                a= self.IL.selectedItems()[0].text().replace(q,dic[q])


        with open("./cache/{0}.md".format(a),'w', encoding='UTF-8') as f:
            f.write('{0}\n{1}\n{2}'.format(num1.strip("\n"),num2.strip("\n"),num3.strip("\n")))


    def init(self):
        with open("./setting/setting.md" , 'r', encoding='UTF-8') as f:  
            self.o=[]
            line=f.readline()
            while line:            
                self.o.append(line)
                line = f.readline()

        self.edit1.setText(self.o[0].rstrip("\n"))
        self.edit3.setText(self.o[2])

        if self.o[1][0] == "P":
            self.groupBox3.setChecked(True)
            self.groupBox.setChecked(False)
            self.per.setText(str(100*float(self.o[1][1:])))
        elif self.o[1][0] == "F":
            self.groupBox2.setChecked(True)
            self.groupBox.setChecked(False)
            self.fix.setText(self.o[1][1:])


    def haha(self):
        if  self.groupBox2.isChecked() ==True:
            self.groupBox.setChecked(False)
            self.clear_text_per()
            QTimer.singleShot(10, self.ahah)

        elif self.groupBox3.isChecked() ==True:
            self.groupBox.setChecked(False)
            self.clear_text_fix()
            QTimer.singleShot(10, self.hh)
        
        else:
            QTimer.singleShot(10, self.haha)


    def ahah(self):
        if self.groupBox.isChecked()==True:
            self.groupBox2.setChecked(False)
            self.groupBox3.setChecked(False)
            self.clear_text_fix()
            self.clear_text_per()

            QTimer.singleShot(10, self.haha)

        elif self.groupBox3.isChecked()==True:
            self.groupBox.setChecked(False)
            self.groupBox2.setChecked(False)
            self.clear_text_fix()
            QTimer.singleShot(10, self.hh)
        else:
            QTimer.singleShot(10, self.ahah)

    def hh(self):
        if self.groupBox.isChecked()==True:
            self.groupBox2.setChecked(False)
            self.groupBox3.setChecked(False)
            self.clear_text_fix()
            self.clear_text_per()

            QTimer.singleShot(10, self.haha)

        elif self.groupBox2.isChecked()==True:
            self.groupBox.setChecked(False)
            self.groupBox3.setChecked(False)
            QTimer.singleShot(10, self.ahah)
        else:
            QTimer.singleShot(10, self.hh)

    def compare2(self,count):

        try:
            self.IL.selectedItems()[0]      #確認有選擇商品可以進行設定
            if self.edit3.text() == "":
                self.st()
        
            elif self.edit3.text() !="":    #確認1000股
                if int(self.edit3.text()) % 1000 !=0:
                    if count == 0:
                        self.dwrongmsg = dateWrong("C/")
                    else:
                        self.dwrongmsg = dateWrong("C/",1)
                    self.dwrongmsg.show()
                else:
                    self.st()                
        #except:
        except Exception as e: 
            print (str(e))
            
            if count == 0:
                self.dwrongmsg = dateWrong("NI-S")
            else:
                self.dwrongmsg = dateWrong("NI-S",1)
            self.dwrongmsg.show()

    def clear_text_fix(self):
        self.fix.clear()
        
    def clear_text_per(self):
        self.per.clear()

class updateWindow(QTabWidget):
    def __init__(self, *args, parent = None):
        super(updateWindow, self).__init__(parent)
        self.setWindowTitle('更新商品')

        self.listWidget = QListWidget(self)
        self.listWidget2 = QListWidget(self)
        self.listWidget3 = QListWidget(self)

        item = QtWidgets.QListWidgetItem()
        item2 = QtWidgets.QListWidgetItem()
        item3 = QtWidgets.QListWidgetItem()
        item.setText('商品'+'\t'*2+'說明\n'+'-'*53)
        item2.setText('商品'+'\t'*2+'說明\n'+'-'*53)
        item3.setText('商品'+'\t'*2+'說明\n'+'-'*53)
        
        
        item.setFlags(QtCore.Qt.NoItemFlags)        # item should not be selectable
        self.listWidget.addItem(item)
        self.listWidget.addItems(["%-20s%10s"%("中石化","中國石油化工股份有限公司"), \
            "%-20s%10s"%("台泥","台灣水泥"),"%-20s%10s"%("富邦"," 富邦集團"),\
            "%-20s%10s"%("統一","統一企業"),"%-20s%10s"%("亞聚","亞洲聚合股份有限公司"),\
            "%-20s%10s"%("中鋼","中國鋼鐵股份有限公司")])
        self.listWidget.setFixedSize(330,200)
        
        
        self.listWidget2.addItem(item2)
        self.listWidget2.addItems(["%-20s%10s"%("TWSEAUTO","汽車"), \
            "%-20s%10s"%("TWSECEM","水泥"),"%-20s%10s"%("TWSECON"," 營造建材"),\
            "%-20s%10s"%("TWSEFOOD","食品"),"%-20s%10s"%("TWSERUB","橡膠"),\
            "%-20s%10s"%("TWSESTEE","鋼鐵")])
        self.listWidget2.setFixedSize(330,200)
        
        
        self.listWidget3.addItem(item3)
        self.listWidget3.addItems(["%-20s%10s"%("EXF1","電指期"), \
            "%-20s%10s"%("FXF1","金指期"),"%-20s%10s"%("MXF1","小台期"),\
            "%-20s%10s"%("TXF1","台指期")])
        self.listWidget3.setFixedSize(330,200)
        
        self.addTab(self.listWidget,"股票")
        self.addTab(self.listWidget2,"指數")
        self.addTab(self.listWidget3,"期貨")
        
        self.backbutton = QPushButton('返回',self)
        self.backbutton.move(550, 350)
        self.subbutton = QPushButton('確認更新',self)
        self.subbutton.move(450, 350)

        self.subbutton.clicked.connect(lambda:self.compare(self.currentIndex(),len(args)))
        self.backbutton.clicked.connect(self.close)
        
    def compare(self,index,args_count):
        
        if index == 0:
            mylist = self.listWidget
        elif index == 1:
            mylist = self.listWidget2
        elif index == 2:
            mylist = self.listWidget3
        
        
        for i in mylist.selectedItems():
            a = i.text()[:3].replace(" ","")

        try:
            test(a)

        except UnboundLocalError:
            self.dwrongmsg = dateWrong("NE")
            self.dwrongmsg.show()


class InisetWindow(QWidget):
    def __init__(self,*args, parent = None):
        super(InisetWindow, self).__init__(parent)
        self.setFixedSize(700, 300)
        self.setWindowTitle('初始設定')

        if len(args) == 0:
            strategybutton = QPushButton('確認',self)
            money = QLabel('初始資金',self)
            hand = QLabel('手續費',self)
            count = QLabel('股數',self)
            self.groupBox = QGroupBox('沒有手續費',self)
            self.groupBox2 = QGroupBox('固定',self)
            self.groupBox3 = QGroupBox('按交易金額比例(%)',self)
            strategybutton.clicked.connect(lambda:self.compare2(0))
            #strategybutton.clicked.connect(self.st)
        else:
            self.setWindowTitle('Inital Setting')
            strategybutton = QPushButton('Ok',self)
            money = QLabel('Initial Funds',self)
            hand = QLabel('Commission',self)
            count = QLabel('Number of \nshares\nper trade',self)
            self.groupBox = QGroupBox('No Commission',self)
            self.groupBox2 = QGroupBox('Fixed Commission',self)
            self.groupBox3 = QGroupBox('percent of the transaction(%)',self)
            strategybutton.clicked.connect(lambda:self.compare2(1))

        strategybutton.move(120, 220)
        strategybutton.resize(70,50)        
        money.move(380,35)      
        hand.move(380,120)     
        count.move(380,210)

        self.edit1 = QLineEdit(self)    #初始資金輸入
        self.edit1.move(450,35)
   
   
        self.groupBox.setCheckable(True)
        self.groupBox.setChecked(True)
     
        self.groupBox2.setCheckable(True)
        self.groupBox2.setChecked(False)

        self.fix = QLineEdit(self)      #固定手續費輸入
        grid = QGridLayout()
        grid.addWidget(self.fix,0,0)
        self.groupBox2.setLayout(grid)

        self.groupBox3.setCheckable(True)
        self.groupBox3.setChecked(False)

        self.per = QLineEdit(self)      #按交易比例
        grid = QGridLayout()
        grid.addWidget(self.per,0,0)
        self.groupBox3.setLayout(grid)

        self.groupBox.move(450,70)
        self.groupBox2.move(450,90)
        self.groupBox3.move(450,140)

        self.edit3 = QLineEdit(self)
        self.edit3.move(450,210)

        self.last()
        self.haha()
        

    def st(self):
        if self.edit1.text()=="":    #如果沒有輸入時間週期，跑預設的1
            num1 = self.o[0]
        else:
            num1 = self.edit1.text()

        if  self.fix.text() !="":
            num2 = "F"+self.fix.text()
        elif self.per.text() !="":
            num2 = "P"+str(float(self.per.text())*0.01)
        else:
            num2 = "N"
        
        if self.edit3.text()=="":    #如果沒有輸入時間週期，跑預設的1
            num3 = self.o[2]
        else:
            num3 = self.edit3.text()

        f = open("./setting/setting.md",'w')
        f.write('%s\n%s\n%s'%(num1.strip("\n"),num2.strip("\n"),num3.strip("\n")))

        self.close()

    def last(self):         #判斷上次設定

        with open("./setting/setting.md" , 'r', encoding='UTF-8') as f:
            self.o=[]
            line=f.readline()
            while line:            
                self.o.append(line)
                line = f.readline()

        self.edit1.setText(self.o[0])
        self.edit3.setText(self.o[2])

        if self.o[1][0] == "P":
            self.groupBox3.setChecked(True)
            self.groupBox.setChecked(False)
            self.per.setText(str(100*float(self.o[1][1:])))
        elif self.o[1][0] == "F":
            self.groupBox2.setChecked(True)
            self.groupBox.setChecked(False)
            self.fix.setText(self.o[1][1:])



    def haha(self):
        if  self.groupBox2.isChecked() ==True:
            self.groupBox.setChecked(False)
            self.clear_text_per()
            QTimer.singleShot(10, self.ahah)

        elif self.groupBox3.isChecked() ==True:
            self.groupBox.setChecked(False)
            self.clear_text_fix()
            QTimer.singleShot(10, self.hh)
        
        else:
            QTimer.singleShot(10, self.haha)


    def ahah(self):
        if self.groupBox.isChecked()==True:
            self.groupBox2.setChecked(False)
            self.groupBox3.setChecked(False)
            self.clear_text_fix()
            self.clear_text_per()

            QTimer.singleShot(10, self.haha)

        elif self.groupBox3.isChecked()==True:
            self.groupBox.setChecked(False)
            self.groupBox2.setChecked(False)
            self.clear_text_fix()
            QTimer.singleShot(10, self.hh)
        else:
            QTimer.singleShot(10, self.ahah)

    def hh(self):
        if self.groupBox.isChecked()==True:
            self.groupBox2.setChecked(False)
            self.groupBox3.setChecked(False)
            self.clear_text_fix()
            self.clear_text_per()

            QTimer.singleShot(10, self.haha)

        elif self.groupBox2.isChecked()==True:
            self.groupBox.setChecked(False)
            self.groupBox3.setChecked(False)
            QTimer.singleShot(10, self.ahah)
        else:
            QTimer.singleShot(10, self.hh)

    
    def compare2(self,count):

        if self.edit3.text() == "":
            self.st()

        
        elif self.edit3.text() !="":
            if int(self.edit3.text()) % 1000 !=0:
                if count == 0:
                    self.dwrongmsg = dateWrong("C/")
                else:
                    self.dwrongmsg = dateWrong("C/",1)

                self.dwrongmsg.show()
            else:
                self.st()
    
    def clear_text_fix(self):
        self.fix.clear()
        
    def clear_text_per(self):
        self.per.clear()



class chooseWindow(QTabWidget):
    def __init__(self,*args,parent = None):
        super(chooseWindow, self).__init__(parent)
        style = """QTabWidget::tab-bar{
        alignment: right;
        }QTabWidget::pane{border: 1px solid #eeeeee;}"""
        self.setStyleSheet(style)

        
        self.strategylist = QListWidget(self)
        self.strategylist.addItems(["atr","bollinger","cross","cumret","highlow",\
            "hurst","linebreak","linreg","ma","macd","ratio","roc","rsi","stats","stoch",\
            "vwap"])

        self.strategylist.setFixedSize(200,220)
        self.MSL = QListWidget(self)
        self.MSL.setFixedSize(200,220)
        self.MSL.move(200,200)


        listA = []
        for dirPath, dirNames, fileNames in os.walk \
        ("C:\\Users\\user\\Desktop\\lastest(8.19)\\strategy\\User"):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".md") ]
            for f in fileNames:
                listA.append(f.rstrip(".md"))
        
        self.MSL.addItems(listA)


        tab = QWidget()
        typetablayout = QGridLayout(tab)
        typetablayout.addWidget(self.strategylist)
        typetablayout.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)

        tab2 = QWidget()
        t2layout = QGridLayout(tab2)
        t2layout.addWidget(self.MSL)
        t2layout.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)

        if len(args) == 0:
            self.addTab(tab,"內建")
            self.addTab(tab2,"使用者")
            strategybutton = QPushButton('確認',self)
        else:
            self.addTab(tab,"Internal")
            self.addTab(tab2,"User")
            strategybutton = QPushButton('Ok',self)


        self.IL = QListWidget(self)      #IL(item list) --左側已選擇商品
        self.IL.setFixedSize(240,160)
        self.IL.move(50,35)
        
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"
        listI = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listI.append(f[2:].rstrip(".csv"))

        dic = {"aaa":'台泥', "bbb":'中石化', "ccc":'富邦', "ddd":'統一', "eee":'亞聚', "fff":'中鋼'
    , "ggg":'TWSEAUTO',"hhh":'TWSECEM',"iii":'TWSECON',"jjj":'TWSEFOOD',"kkk":'TWSERUB',"lll":'TWSESTEE'
    ,"mmm":'EXF1',"nnn":'FXF1',"ooo":'MXF1',"ppp":'TXF1'}
        
        for i in range(len(listI)):
            for p in dic:
                if listI[i].find(p) != -1:
                    listI[i] = listI[i].replace(p,dic[p])

        self.IL.addItems(listI)
 
        strategybutton.move(120, 220)
        strategybutton.resize(70,50)

        self.bigtimer()
        strategybutton.clicked.connect(self.compare)

    def bigtimer(self):
        try:
            self.strategylist.selectedItems()[0].text()
            QTimer.singleShot(10, self.timer)
        except:
            QTimer.singleShot(10, self.smalltimer)

    def smalltimer(self):

        try:
            self.MSL.selectedItems()[0].text()
            QTimer.singleShot(10, self.realtimer)
        except:
            QTimer.singleShot(10, self.bigtimer)


    def timer(self):
        try:
            self.strategylist.selectedItems()[0].text()
            self.clear(self.MSL)
            self.realtimer()          
        except:
            QTimer.singleShot(10, self.timer)
    def realtimer(self):

        try:
            self.MSL.selectedItems()[0].text()
            self.clear(self.strategylist)
            self.timer()            
        except:
            QTimer.singleShot(10, self.realtimer)
  
    def clear(self,listwidget):
        listwidget.clearSelection()

    def compare(self):
        a = None; b = None; c = None
        for i in self.strategylist.selectedItems():
            a = i.text()

        for j in self.MSL.selectedItems():
            b = j.text()

        for x in self.IL.selectedItems():
            c = x.text()
        
        if c == None:
            self.dwrongmsg = dateWrong("NI-C")
            self.dwrongmsg.show()

        elif a == None and b ==None:
            self.dwrongmsg = dateWrong("NS")
            self.dwrongmsg.show()

        else:
            try:
                self.pyalgostrategy(c,self.strategylist.selectedItems()[0].text())
                self.close()
            #except Exception as e:
            #    print(str(e))
            except:
                self.pyalgostrategy(c,"my"+self.MSL.selectedItems()[0].text())
                self.close()
    def main():
        app = QApplication(sys.argv)
        mainwindow = MainWindow()
        mainwindow.show()

    def pyalgostrategy(self,name,strategyname):
        dic = {"台泥":'aaa', "中石化":'bbb', "富邦":'ccc', "統一":'ddd', "亞聚":'eee', "中鋼":'fff'
    , "TWSEAUTO":'ggg',"TWSECEM":'hhh',"TWSECON":'iii',"TWSEFOOD":'jjj',"TWSERUB":'kkk',"TWSESTEE":'lll'
    ,"EXF1":'mmm',"FXF1":'nnn',"MXF1":'ooo',"TXF1":'ppp'}

    
        for r in dic:
            if name.find(r) !=-1:
                c = name.replace(r,dic[r])
                      
        if strategyname =="ma": 
            f = open("./cache/%s.txt"%(c),'w')
            f.write('ma'+'\n'+'150')
        elif strategyname =="macd":
            f = open("./cache/%s.txt"%(c),'w')
            f.write('macd'+'\n'+'12'+'\n'+'26'+'\n'+'9')
        elif strategyname =="rsi":
            f = open("./cache/%s.txt"%(c),'w')
            f.write('rsi'+'\n'+'14'+'\n'+'6')
        elif strategyname[:2] == "my":
            f = open("./cache/%s.txt"%(c),'w')
            f.write('%s'%(strategyname))
            #print("相信使用者的%s"%(strategyname))
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"
        listI = []
        for dirPath, dirNames, fileNames in os.walk (path):
            fileNames = [ fi for fi in fileNames if  fi.endswith(".csv") ]
            for f in fileNames:
                listI.append(f.rstrip(".csv"))
        
        for i in range(len(listI)):
                if listI[i].find(c) != -1:
                    a = listI[i]

        b = str(int(a[0])+1)+a[1:]

        print("rename %s.csv %s.csv"%(a,b))
        path = "C:\\Users\\user\\Desktop\\lastest(8.19)\\cache"

        os.system("rename %s\\%s.csv %s.csv"%(path,a,b))
       

    def onActivated(self, text):
      
        self.lbl2.setText(text)
        self.lbl2.adjustSize()
class checkWindow(QWidget):
    def __init__(self, parent = None):
        super(checkWindow, self).__init__(parent)
        self.setFixedSize(800, 600)
        self.setWindowTitle('內建交易策略')

    def main():
        app = QApplication(sys.argv)
        mainwindow = MainWindow()
        mainwindow.show()


class exchangeWindow(QWidget):
    def __init__(self, parent = None):
        super(exchangeWindow, self).__init__(parent)
        self.setGeometry(600,350,400,280)
        self.setWindowTitle('選擇證券交易所')

        stockcombo = QComboBox(self)

        stockcombo.addItems(["元大寶來","凱基","日盛"])
        stockcombo.move(150, 50)

        self.account = QLineEdit(self)
        self.password = QLineEdit(self)
        self.ac_in = QLabel("帳號",self)
        self.pa_in = QLabel("密碼",self)
    
        self.ac_in.move(80,100)
        self.pa_in.move(80,140)
        self.account.move(120,100)
        self.password.move(120,140)

        subbutton = QPushButton('確認',self)
        subbutton.move(130,220)
        self.password.setEchoMode(QLineEdit.Password)

        subbutton.clicked.connect(lambda:insql(stockcombo.currentText(),self.account.text(),self.password.text()))
        subbutton.clicked.connect(self.close) #不用命名的函數 單次使用而已

    def main():
        app = QApplication(sys.argv)
        mainwindow = MainWindow()
        mainwindow.show()

class MainWindow(QMainWindow, firstWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.initUI()
    def closeEvent(self, event):        #清除cache
        os.system("del /F/S/Q cache")
    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())